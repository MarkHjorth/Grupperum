﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Grupperum_Website_Klient.Models.Home
{
    public class FinishModel
    {
        public bool RentedGroupRoom { get; set; }
        public bool ListedToClassRoom { get; set; }
    }
}